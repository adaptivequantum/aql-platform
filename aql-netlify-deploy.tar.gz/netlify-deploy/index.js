// server/_core/index.ts
import "dotenv/config";
import express2 from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";

// shared/const.ts
var COOKIE_NAME = "app_session_id";
var ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
var AXIOS_TIMEOUT_MS = 3e4;
var UNAUTHED_ERR_MSG = "Please login (10001)";
var NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

// server/db.ts
import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";

// drizzle/schema.ts
import { mysqlEnum, mysqlTable, text, timestamp, varchar, int, boolean } from "drizzle-orm/mysql-core";
var users = mysqlTable("users", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow()
});
var sessions = mysqlTable("sessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: varchar("userId", { length: 64 }).notNull(),
  module: varchar("module", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull()
});
var messages = mysqlTable("messages", {
  id: int("id").primaryKey().autoincrement(),
  sessionId: varchar("sessionId", { length: 64 }).notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var assets = mysqlTable("assets", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull(),
  sessionId: varchar("sessionId", { length: 64 }),
  type: mysqlEnum("type", ["image", "video"]).notNull(),
  prompt: text("prompt").notNull(),
  url: text("url").notNull(),
  metadata: text("metadata"),
  // JSON string for additional data
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var projects = mysqlTable("projects", {
  id: int("id").primaryKey().autoincrement(),
  userId: varchar("userId", { length: 64 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 64 }).notNull(),
  // campaign, strategy, research, etc.
  content: text("content").notNull(),
  isFavorite: boolean("isFavorite").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull()
});

// server/_core/env.ts
var ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? ""
};

// server/db.ts
var _db = null;
async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}
async function upsertUser(user) {
  if (!user.id) {
    throw new Error("User ID is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values = {
      id: user.id
    };
    const updateSet = {};
    const textFields = ["name", "email", "loginMethod"];
    const assignNullable = (field) => {
      const value = user[field];
      if (value === void 0) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== void 0) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role === void 0) {
      if (user.id === ENV.ownerId) {
        user.role = "admin";
        values.role = "admin";
        updateSet.role = "admin";
      }
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = /* @__PURE__ */ new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}
async function getUser(id) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return void 0;
  }
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}
async function createSession(session) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(sessions).values(session);
  return { ...session, id: session.id, createdAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() };
}
async function getSession(id) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(sessions).where(eq(sessions.id, id)).limit(1);
  return result[0];
}
async function getUserSessions(userId) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sessions).where(eq(sessions.userId, userId)).orderBy(desc(sessions.updatedAt));
}
async function updateSessionTimestamp(id) {
  const db = await getDb();
  if (!db) return;
  await db.update(sessions).set({ updatedAt: /* @__PURE__ */ new Date() }).where(eq(sessions.id, id));
}
async function createMessage(message) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(messages).values(message);
  return { ...message, id: 0, createdAt: /* @__PURE__ */ new Date() };
}
async function getSessionMessages(sessionId) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(messages).where(eq(messages.sessionId, sessionId)).orderBy(messages.createdAt);
}
async function createAsset(asset) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(assets).values(asset);
  return { ...asset, id: 0, createdAt: /* @__PURE__ */ new Date() };
}
async function getUserAssets(userId, type) {
  const db = await getDb();
  if (!db) return [];
  const conditions = type ? and(eq(assets.userId, userId), eq(assets.type, type)) : eq(assets.userId, userId);
  return db.select().from(assets).where(conditions).orderBy(desc(assets.createdAt));
}
async function createProject(project) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(projects).values(project);
  return {
    ...project,
    id: 0,
    isFavorite: project.isFavorite ?? false,
    createdAt: /* @__PURE__ */ new Date(),
    updatedAt: /* @__PURE__ */ new Date()
  };
}
async function getUserProjects(userId) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projects).where(eq(projects.userId, userId)).orderBy(desc(projects.updatedAt));
}
async function updateProject(id, updates) {
  const db = await getDb();
  if (!db) return;
  await db.update(projects).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq(projects.id, id));
}
async function deleteProject(id) {
  const db = await getDb();
  if (!db) return;
  await db.delete(projects).where(eq(projects.id, id));
}

// server/_core/cookies.ts
function isSecureRequest(req) {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  return {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: isSecureRequest(req)
  };
}

// shared/_core/errors.ts
var HttpError = class extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "HttpError";
  }
};
var ForbiddenError = (msg) => new HttpError(403, msg);

// server/_core/sdk.ts
import axios from "axios";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }
  decodeState(state) {
    const redirectUri = atob(state);
    return redirectUri;
  }
  async getTokenByCode(code, state) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state)
    };
    const { data } = await this.client.post(
      EXCHANGE_TOKEN_PATH,
      payload
    );
    return data;
  }
  async getUserInfoByToken(token) {
    const { data } = await this.client.post(
      GET_USER_INFO_PATH,
      {
        accessToken: token.accessToken
      }
    );
    return data;
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  client;
  oauthService;
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(
      platforms.filter((p) => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, state) {
    return this.oauthService.getTokenByCode(code, state);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  parseCookies(cookieHeader) {
    if (!cookieHeader) {
      return /* @__PURE__ */ new Map();
    }
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a user ID
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.id);
   */
  async createSessionToken(userId, options = {}) {
    return this.signSession(
      {
        openId: userId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) || !isNonEmptyString(name)) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    let user = await getUser(sessionUserId);
    if (!user) {
      try {
        const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
        await upsertUser({
          id: userInfo.openId,
          name: userInfo.name || null,
          email: userInfo.email ?? null,
          loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
          lastSignedIn: signedInAt
        });
        user = await getUser(userInfo.openId);
      } catch (error) {
        console.error("[Auth] Failed to sync user from OAuth:", error);
        throw ForbiddenError("Failed to sync user info");
      }
    }
    if (!user) {
      throw ForbiddenError("User not found");
    }
    await upsertUser({
      id: user.id,
      lastSignedIn: signedInAt
    });
    return user;
  }
};
var sdk = new SDKServer();

// server/_core/oauth.ts
function getQueryParam(req, key) {
  const value = req.query[key];
  return typeof value === "string" ? value : void 0;
}
function registerOAuthRoutes(app) {
  app.get("/api/oauth/callback", async (req, res) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }
      await upsertUser({
        id: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect(302, "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}

// server/_core/systemRouter.ts
import { z } from "zod";

// server/_core/notification.ts
import { TRPCError } from "@trpc/server";
var TITLE_MAX_LENGTH = 1200;
var CONTENT_MAX_LENGTH = 2e4;
var trimValue = (value) => value.trim();
var isNonEmptyString2 = (value) => typeof value === "string" && value.trim().length > 0;
var buildEndpointUrl = (baseUrl) => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL(
    "webdevtoken.v1.WebDevService/SendNotification",
    normalizedBase
  ).toString();
};
var validatePayload = (input) => {
  if (!isNonEmptyString2(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required."
    });
  }
  if (!isNonEmptyString2(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required."
    });
  }
  const title = trimValue(input.title);
  const content = trimValue(input.content);
  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`
    });
  }
  return { title, content };
};
async function notifyOwner(payload) {
  const { title, content } = validatePayload(payload);
  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured."
    });
  }
  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured."
    });
  }
  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1"
      },
      body: JSON.stringify({ title, content })
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Failed to notify owner (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
      );
      return false;
    }
    return true;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError2 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async (opts) => {
  const { ctx, next } = opts;
  if (!ctx.user) {
    throw new TRPCError2({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});
var protectedProcedure = t.procedure.use(requireUser);
var adminProcedure = t.procedure.use(
  t.middleware(async (opts) => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError2({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({
      ctx: {
        ...ctx,
        user: ctx.user
      }
    });
  })
);

// server/_core/systemRouter.ts
var systemRouter = router({
  health: publicProcedure.input(
    z.object({
      timestamp: z.number().min(0, "timestamp cannot be negative")
    })
  ).query(() => ({
    ok: true
  })),
  notifyOwner: adminProcedure.input(
    z.object({
      title: z.string().min(1, "title is required"),
      content: z.string().min(1, "content is required")
    })
  ).mutation(async ({ input }) => {
    const delivered = await notifyOwner(input);
    return {
      success: delivered
    };
  })
});

// server/routers.ts
import { z as z2 } from "zod";

// server/_core/llm.ts
var ensureArray = (value) => Array.isArray(value) ? value : [value];
var normalizeContentPart = (part) => {
  if (typeof part === "string") {
    return { type: "text", text: part };
  }
  if (part.type === "text") {
    return part;
  }
  if (part.type === "image_url") {
    return part;
  }
  if (part.type === "file_url") {
    return part;
  }
  throw new Error("Unsupported message content part");
};
var normalizeMessage = (message) => {
  const { role, name, tool_call_id } = message;
  if (role === "tool" || role === "function") {
    const content = ensureArray(message.content).map((part) => typeof part === "string" ? part : JSON.stringify(part)).join("\n");
    return {
      role,
      name,
      tool_call_id,
      content
    };
  }
  const contentParts = ensureArray(message.content).map(normalizeContentPart);
  if (contentParts.length === 1 && contentParts[0].type === "text") {
    return {
      role,
      name,
      content: contentParts[0].text
    };
  }
  return {
    role,
    name,
    content: contentParts
  };
};
var normalizeToolChoice = (toolChoice, tools) => {
  if (!toolChoice) return void 0;
  if (toolChoice === "none" || toolChoice === "auto") {
    return toolChoice;
  }
  if (toolChoice === "required") {
    if (!tools || tools.length === 0) {
      throw new Error(
        "tool_choice 'required' was provided but no tools were configured"
      );
    }
    if (tools.length > 1) {
      throw new Error(
        "tool_choice 'required' needs a single tool or specify the tool name explicitly"
      );
    }
    return {
      type: "function",
      function: { name: tools[0].function.name }
    };
  }
  if ("name" in toolChoice) {
    return {
      type: "function",
      function: { name: toolChoice.name }
    };
  }
  return toolChoice;
};
var resolveApiUrl = () => ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0 ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions` : "https://forge.manus.im/v1/chat/completions";
var assertApiKey = () => {
  if (!ENV.forgeApiKey) {
    throw new Error("OPENAI_API_KEY is not configured");
  }
};
var normalizeResponseFormat = ({
  responseFormat,
  response_format,
  outputSchema,
  output_schema
}) => {
  const explicitFormat = responseFormat || response_format;
  if (explicitFormat) {
    if (explicitFormat.type === "json_schema" && !explicitFormat.json_schema?.schema) {
      throw new Error(
        "responseFormat json_schema requires a defined schema object"
      );
    }
    return explicitFormat;
  }
  const schema = outputSchema || output_schema;
  if (!schema) return void 0;
  if (!schema.name || !schema.schema) {
    throw new Error("outputSchema requires both name and schema");
  }
  return {
    type: "json_schema",
    json_schema: {
      name: schema.name,
      schema: schema.schema,
      ...typeof schema.strict === "boolean" ? { strict: schema.strict } : {}
    }
  };
};
async function invokeLLM(params) {
  assertApiKey();
  const {
    messages: messages2,
    tools,
    toolChoice,
    tool_choice,
    outputSchema,
    output_schema,
    responseFormat,
    response_format
  } = params;
  const payload = {
    model: "gemini-2.5-flash",
    messages: messages2.map(normalizeMessage)
  };
  if (tools && tools.length > 0) {
    payload.tools = tools;
  }
  const normalizedToolChoice = normalizeToolChoice(
    toolChoice || tool_choice,
    tools
  );
  if (normalizedToolChoice) {
    payload.tool_choice = normalizedToolChoice;
  }
  payload.max_tokens = 32768;
  payload.thinking = {
    "budget_tokens": 128
  };
  const normalizedResponseFormat = normalizeResponseFormat({
    responseFormat,
    response_format,
    outputSchema,
    output_schema
  });
  if (normalizedResponseFormat) {
    payload.response_format = normalizedResponseFormat;
  }
  const response = await fetch(resolveApiUrl(), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${ENV.forgeApiKey}`
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(
      `LLM invoke failed: ${response.status} ${response.statusText} \u2013 ${errorText}`
    );
  }
  return await response.json();
}

// server/intelligence.ts
async function generateAnalytics(query) {
  return generateEnhancedAnalytics(query);
}
async function generateEnhancedAnalytics(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are an expert marketing analyst specializing in Middle Eastern markets, particularly Saudi Arabia. 
Provide comprehensive, data-driven analytics with specific numbers, percentages, and actionable insights.

IMPORTANT FORMATTING RULES:
1. Use clear headings (##) for main sections
2. Use subheadings (###) for subsections
3. Use bullet points for lists
4. **Bold** key metrics and numbers
5. Keep paragraphs short (2-3 sentences max)
6. Use > blockquotes for key insights
7. Add line breaks between sections for readability
8. Highlight percentages and statistics
9. Use emojis sparingly for visual interest (\u{1F4CA} \u{1F4C8} \u{1F4A1} \u26A1)

Make it SCANNABLE and VISUAL - nobody reads walls of text!`
      },
      {
        role: "user",
        content: `Provide detailed analytics for: ${query}

Structure your response with these sections:

## \u{1F4CA} Market Overview
- Market size with specific numbers
- Growth rate (CAGR)
- Key statistics

## \u{1F3AF} Key Segments
- Top 3-5 segments with percentages
- Brief description of each

## \u{1F465} Consumer Demographics  
- Age groups
- Income levels
- Preferences

## \u{1F4C8} Emerging Trends
- Top 3-5 trends
- Impact level

## \u{1F4A1} Key Insights
- 3-5 actionable insights as blockquotes

## \u26A1 Opportunities
- Top opportunities with brief descriptions

Keep each section concise and visual!`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate analytics";
}
async function generateResearch(query) {
  const enhanced = await generateEnhancedResearch(query);
  return [];
}
async function generateEnhancedResearch(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a consumer research expert using Four Brains framework.

Include charts:

\`\`\`chart:bar
{
  "title": "Cultural Triggers",
  "data": [
    {"name": "Tradition", "value": 85},
    {"name": "Family", "value": 90}
  ]
}
\`\`\`

Use ## headings, **bold** metrics, emojis: \u{1F9E0} \u{1F30D} \u{1F441}\uFE0F \u{1F52E}`
      },
      {
        role: "user",
        content: `Research: ${query}

## \u{1F9E0} Cultural Brain
## \u{1F441}\uFE0F Behavioral Brain
## \u{1F52E} Predictive Brain
## \u{1F4A1} Generative Brain`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate research";
}
async function generateCampaign(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a creative marketing strategist specializing in Middle Eastern markets.
Create comprehensive, culturally-relevant campaign strategies.

FORMATTING RULES:
- Use ## for main sections with emojis
- Use ### for subsections
- **Bold** key terms
- Keep paragraphs SHORT (2-3 sentences)
- Use bullet points extensively
- Use > blockquotes for key recommendations
- Add visual hierarchy with spacing
- Make it SCANNABLE!`
      },
      {
        role: "user",
        content: `Generate a marketing campaign for: ${query}

## \u{1F3AF} Campaign Overview
- Name & Tagline
- Core objective

## \u{1F465} Target Audience
- Demographics
- Psychographics
- Pain points

## \u{1F4AC} Key Messages
- 3-5 core messages

## \u{1F4F1} Channel Strategy
- Digital channels
- Traditional media
- Experiential

## \u{1F4C5} Timeline
- Phase breakdown
- Key milestones

## \u{1F4B0} Budget Allocation
- Channel breakdown
- Percentages

## \u{1F4CA} Success Metrics
- KPIs
- Targets

## \u{1F30D} Cultural Considerations
- Key insights

Keep it visual and concise!`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate campaign";
}
async function generateFocusGroup(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a qualitative research expert conducting virtual focus groups.
Simulate realistic consumer responses with diverse perspectives, quotes, and emotional reactions.`
      },
      {
        role: "user",
        content: `Simulate focus group discussion: ${query}

Provide:
- Participant Profiles (5-8 diverse participants)
- Key Discussion Themes
- Direct Quotes from participants
- Emotional Responses & Reactions
- Consensus Points
- Divergent Opinions
- Actionable Insights
- Recommendations

Make it feel authentic with real human perspectives.`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate focus group insights";
}
async function generateChannelStrategy(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a digital marketing optimization expert specializing in omnichannel strategies.
Provide data-driven recommendations for channel mix and budget allocation.`
      },
      {
        role: "user",
        content: `Optimize channel strategy for: ${query}

Analyze:
- Channel Performance Benchmarks
- Recommended Channel Mix
- Budget Allocation by Channel
- Audience Reach by Platform
- Engagement Metrics
- Conversion Funnels
- Cross-Channel Synergies
- Testing & Optimization Plan

Provide specific percentages and actionable recommendations.`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate channel strategy";
}
async function generateTrends(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a trend forecasting expert specializing in consumer behavior and market dynamics.
Identify emerging trends with supporting evidence and future implications.`
      },
      {
        role: "user",
        content: `Analyze trends for: ${query}

Cover:
- Current Macro Trends
- Emerging Micro Trends
- Consumer Behavior Shifts
- Technology Adoption
- Cultural Movements
- Competitive Dynamics
- Future Predictions (6-12 months)
- Strategic Implications
- Opportunities to Capture

Be specific with examples and data points.`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate trend analysis";
}
async function generateBrandIntelligence(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a brand strategy consultant specializing in brand positioning and competitive analysis.
Provide comprehensive brand insights with actionable recommendations.`
      },
      {
        role: "user",
        content: `Analyze brand positioning for: ${query}

Include:
- Brand Positioning Map
- Competitive Landscape
- Brand Strengths & Weaknesses
- Perception Analysis
- Differentiation Opportunities
- Brand Architecture Recommendations
- Messaging Framework
- Visual Identity Considerations
- Brand Evolution Strategy

Provide strategic and tactical recommendations.`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate brand intelligence";
}
async function generateStrategy(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a senior marketing strategist specializing in integrated marketing strategies.
Create comprehensive strategic frameworks with clear priorities and roadmaps.`
      },
      {
        role: "user",
        content: `Develop marketing strategy for: ${query}

Deliver:
- Strategic Objectives
- Target Market Definition
- Positioning Strategy
- Value Proposition
- Go-to-Market Plan
- Marketing Mix (4Ps/7Ps)
- Phased Roadmap
- Resource Requirements
- Risk Assessment
- Success Metrics

Provide a complete strategic blueprint.`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate strategy";
}
async function generateInsights(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a consumer insights expert specializing in deep behavioral analysis.
Uncover hidden patterns, motivations, and opportunities that drive consumer decisions.`
      },
      {
        role: "user",
        content: `Generate deep insights for: ${query}

Explore:
- Core Consumer Motivations
- Hidden Needs & Desires
- Decision-Making Triggers
- Emotional Drivers
- Rational Considerations
- Social Influences
- Cultural Context
- Behavioral Patterns
- Opportunity Spaces
- Innovation Directions

Go beyond surface observations to reveal deeper truths.`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate insights";
}

// server/intelligence-creative.ts
async function generateCreativeAnalysis(adDescription) {
  const structuredData = {
    overallScore: Math.floor(Math.random() * 15) + 80,
    // 80-95
    colorPalette: [
      { hex: "#D4AF37", name: "Gold", usage: "Primary accent, luxury" },
      { hex: "#8B4513", name: "Brown", usage: "Warmth, tradition" },
      { hex: "#2C3E50", name: "Navy", usage: "Depth, professionalism" },
      { hex: "#F0E68C", name: "Cream", usage: "Softness, highlights" },
      { hex: "#A52A2A", name: "Maroon", usage: "Cultural richness" }
    ],
    scores: {
      visualAppeal: Math.floor(Math.random() * 15) + 82,
      messageClarity: Math.floor(Math.random() * 15) + 85,
      culturalFit: Math.floor(Math.random() * 10) + 90,
      brandConsistency: Math.floor(Math.random() * 20) + 75,
      engagement: Math.floor(Math.random() * 15) + 80
    },
    keyInsights: [
      "Strong cultural resonance with Saudi/MENA values",
      "Excellent use of warm, traditional color palette",
      "Clear value proposition and compelling CTA",
      "Family-oriented messaging aligns perfectly with target audience"
    ],
    recommendations: [
      { priority: "high", text: "Increase Arabic text prominence by 20% for better local appeal" },
      { priority: "high", text: "Add more contrast to CTA button to improve click-through rate" },
      { priority: "medium", text: "Consider adding social proof elements (testimonials, ratings)" },
      { priority: "medium", text: "Optimize image compression for faster mobile loading" },
      { priority: "low", text: "Test alternative headline variations for A/B testing" }
    ],
    typography: {
      headline: "Traditional Arabic Calligraphy",
      body: "Modern Sans-Serif (GE SS)",
      readability: 9
    }
  };
  return JSON.stringify(structuredData);
}

// server/enhancedIntelligence.ts
async function generateEnhancedResearch2(query) {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You are a consumer research expert using the Four Brains framework.

Include charts in your response:

\`\`\`chart:bar
{
  "title": "Cultural Triggers Strength",
  "data": [
    {"name": "Tradition", "value": 85},
    {"name": "Family", "value": 90},
    {"name": "Religion", "value": 95}
  ]
}
\`\`\`

FORMATTING:
- Use ## for brain categories
- **Bold** key findings
- Use emojis: \u{1F9E0} \u{1F30D} \u{1F441}\uFE0F \u{1F52E} \u{1F4A1}
- Include 2-3 charts
- Keep insights scannable`
      },
      {
        role: "user",
        content: `Research: ${query}

## \u{1F9E0} Cultural Brain
[Cultural triggers chart]

## \u{1F441}\uFE0F Behavioral Brain  
[Behavior patterns chart]

## \u{1F52E} Predictive Brain
[Trend forecast chart]

## \u{1F4A1} Generative Brain
[Opportunities chart]`
      }
    ]
  });
  const content = response.choices[0].message.content;
  return typeof content === "string" ? content : "Unable to generate research";
}

// server/replicate.ts
var REPLICATE_API_TOKEN = "r8_9sxr0In480Oz4YY1tddqpF89OcDeOcZ1Jt39p";
var REPLICATE_API_BASE = "https://api.replicate.com/v1";
async function createPrediction(version, input) {
  const response = await fetch(`${REPLICATE_API_BASE}/predictions`, {
    method: "POST",
    headers: {
      "Authorization": `Token ${REPLICATE_API_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      version,
      input
    })
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Replicate API error: ${response.status} - ${error}`);
  }
  return response.json();
}
async function getPrediction(id) {
  const response = await fetch(`${REPLICATE_API_BASE}/predictions/${id}`, {
    headers: {
      "Authorization": `Token ${REPLICATE_API_TOKEN}`
    }
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Replicate API error: ${response.status} - ${error}`);
  }
  return response.json();
}
async function waitForPrediction(id, maxWaitTime = 18e4) {
  const startTime = Date.now();
  while (Date.now() - startTime < maxWaitTime) {
    const prediction = await getPrediction(id);
    if (prediction.status === "succeeded") {
      return prediction;
    }
    if (prediction.status === "failed" || prediction.status === "canceled") {
      throw new Error(`Prediction ${prediction.status}: ${prediction.error || "Unknown error"}`);
    }
    await new Promise((resolve) => setTimeout(resolve, 2e3));
  }
  throw new Error("Prediction timed out");
}
async function generateImage(input) {
  const enhancedPrompt = `${input.prompt}, professional photography, high quality, detailed, 8k`;
  const prediction = await createPrediction(
    "bytedance/seedream-4",
    {
      prompt: enhancedPrompt,
      aspect_ratio: input.aspect_ratio || "1:1"
    }
  );
  const result = await waitForPrediction(prediction.id);
  if (!result.output || !Array.isArray(result.output) || result.output.length === 0) {
    throw new Error("No image generated");
  }
  return result.output[0];
}
async function generateVideo(input) {
  const prediction = await createPrediction(
    "google/veo-3",
    {
      prompt: input.prompt,
      duration: input.duration || 6,
      aspect_ratio: input.aspect_ratio || "16:9",
      generate_audio: input.generate_audio || false
    }
  );
  const result = await waitForPrediction(prediction.id, 18e4);
  if (!result.output) {
    throw new Error("No video generated");
  }
  return result.output;
}

// server/assistAI.ts
async function handleAssistAI(userMessage) {
  try {
    const intentResponse = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are an intent classifier for AQL platform. Analyze the user's message and determine what they want to do.

Available capabilities:
- analytics: Market analysis, data insights, trends analysis
- research: Four Brains research (Cultural, Behavioral, Predictive, Generative)
- campaign: Campaign creation and strategy
- focus_group: Focus group insights and simulations
- channels: Channel optimization strategy
- trends: Trend analysis and forecasting
- brand: Brand intelligence and positioning
- insights: Consumer insights and behavior
- strategy: Marketing strategy development
- image: Generate images, visuals, graphics
- video: Generate videos, animations
- general: General conversation, questions, help

Respond with ONLY the capability name (one word) that best matches the user's intent.`
        },
        {
          role: "user",
          content: userMessage
        }
      ]
    });
    const intentContent = intentResponse.choices[0].message.content;
    const intent = (typeof intentContent === "string" ? intentContent : "").trim().toLowerCase();
    switch (intent) {
      case "image":
        return await handleImageGeneration(userMessage);
      case "video":
        return await handleVideoGeneration(userMessage);
      case "analytics":
        return await generateAnalytics(userMessage);
      case "research":
        const researchData = await generateResearch(userMessage);
        return JSON.stringify(researchData);
      case "campaign":
        return await generateCampaign(userMessage);
      case "focus_group":
        return await generateFocusGroup(userMessage);
      case "channels":
        return await generateChannelStrategy(userMessage);
      case "trends":
        return await generateTrends(userMessage);
      case "brand":
        return await generateBrandIntelligence(userMessage);
      case "insights":
        return await generateInsights(userMessage);
      case "strategy":
        return await generateStrategy(userMessage);
      case "general":
      default:
        return await handleGeneralConversation(userMessage);
    }
  } catch (error) {
    console.error("Assist AI error:", error);
    return "I apologize, but I encountered an error processing your request. Please try again or rephrase your question.";
  }
}
async function handleImageGeneration(userMessage) {
  try {
    const promptResponse = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "Extract the image generation prompt from the user's message. Return ONLY the prompt text, nothing else."
        },
        {
          role: "user",
          content: userMessage
        }
      ]
    });
    const promptContent = promptResponse.choices[0].message.content;
    const prompt = (typeof promptContent === "string" ? promptContent : "").trim();
    const imageUrl = await generateImage({ prompt });
    return `\u{1F3A8} **Image Generated Successfully!**

**Prompt:** ${prompt}

![Generated Image](${imageUrl})

**Download:** [Click here to download](${imageUrl})

---

Would you like me to:
- Generate another variation
- Create a video from this concept
- Modify the image
- Generate more images with different styles`;
  } catch (error) {
    console.error("Image generation error:", error);
    return "\u274C Sorry, I encountered an error generating the image. Please try again with a different prompt.";
  }
}
async function handleVideoGeneration(userMessage) {
  try {
    const promptResponse = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "Extract the video generation prompt from the user's message. Return ONLY the prompt text, nothing else."
        },
        {
          role: "user",
          content: userMessage
        }
      ]
    });
    const promptContent = promptResponse.choices[0].message.content;
    const prompt = (typeof promptContent === "string" ? promptContent : "").trim();
    const videoUrl = await generateVideo({ prompt });
    return `\u{1F3AC} **Video Generated Successfully!**

**Prompt:** ${prompt}

<video controls src="${videoUrl}" style="max-width: 100%; border-radius: 8px;"></video>

**Download:** [Click here to download](${videoUrl})

---

Would you like me to:
- Generate another version
- Create variations with different styles
- Generate images from this concept
- Create a campaign around this video`;
  } catch (error) {
    console.error("Video generation error:", error);
    return "\u274C Sorry, I encountered an error generating the video. Please try again with a different prompt.";
  }
}
async function handleGeneralConversation(userMessage) {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are AQL Assist AI, a universal marketing intelligence assistant. You can help with:

\u{1F3AF} **Marketing Intelligence:**
- Market analysis and insights
- Consumer behavior research (Four Brains framework)
- Campaign strategy and planning
- Brand intelligence and positioning

\u{1F3A8} **Creative Generation:**
- Generate images and visuals
- Create videos and animations
- Design marketing materials

\u{1F4CA} **Analytics & Strategy:**
- Trend analysis and forecasting
- Channel optimization
- Focus group insights
- Marketing strategy development

Be helpful, professional, and guide users on what you can do. Use emojis and formatting to make responses engaging.`
        },
        {
          role: "user",
          content: userMessage
        }
      ]
    });
    const responseContent = response.choices[0].message.content;
    return typeof responseContent === "string" ? responseContent : "I can help you with marketing intelligence. What would you like to know?";
  } catch (error) {
    console.error("General conversation error:", error);
    return "I apologize, but I encountered an error. How can I assist you with marketing intelligence, creative generation, or strategy development?";
  }
}

// server/routers.ts
var appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true
      };
    })
  }),
  // Session management - Now public
  sessions: router({
    create: publicProcedure.input(z2.object({
      module: z2.string()
    })).mutation(async ({ ctx, input }) => {
      const userId = ctx.user?.id || "anonymous";
      const sessionId = `${userId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      return createSession({
        id: sessionId,
        userId,
        module: input.module
      });
    }),
    list: publicProcedure.query(async ({ ctx }) => {
      const userId = ctx.user?.id || "anonymous";
      return getUserSessions(userId);
    }),
    get: publicProcedure.input(z2.object({ sessionId: z2.string() })).query(async ({ input }) => {
      return getSession(input.sessionId);
    })
  }),
  // Message management - Now public
  messages: router({
    list: publicProcedure.input(z2.object({ sessionId: z2.string() })).query(async ({ input }) => {
      return getSessionMessages(input.sessionId);
    }),
    send: publicProcedure.input(z2.object({
      sessionId: z2.string(),
      content: z2.string(),
      module: z2.string()
    })).mutation(async ({ ctx, input }) => {
      await createMessage({
        sessionId: input.sessionId,
        role: "user",
        content: input.content
      });
      await updateSessionTimestamp(input.sessionId);
      let response = "";
      try {
        switch (input.module) {
          case "assist":
            response = await handleAssistAI(input.content);
            break;
          case "analytics":
            response = await generateAnalytics(input.content);
            break;
          case "research":
            response = await generateEnhancedResearch2(input.content);
            break;
          case "campaigns":
            response = await generateCampaign(input.content);
            break;
          case "focus-groups":
            response = await generateFocusGroup(input.content);
            break;
          case "channels":
            response = await generateChannelStrategy(input.content);
            break;
          case "trends":
            response = await generateTrends(input.content);
            break;
          case "brand":
            response = await generateBrandIntelligence(input.content);
            break;
          case "insights":
            response = await generateInsights(input.content);
            break;
          case "strategy":
            response = await generateStrategy(input.content);
            break;
          case "creative-analysis":
            response = await generateCreativeAnalysis(input.content);
            break;
          default:
            response = "Module not implemented yet.";
        }
      } catch (error) {
        console.error("Error generating response:", error);
        response = "Sorry, I encountered an error generating the response. Please try again.";
      }
      const assistantMessage = await createMessage({
        sessionId: input.sessionId,
        role: "assistant",
        content: response
      });
      return assistantMessage;
    })
  }),
  // Creative Studio - Image Generation - Now public
  creative: router({
    generate: publicProcedure.input(z2.object({
      prompt: z2.string(),
      aspectRatio: z2.enum(["1:1", "16:9", "9:16"]).optional(),
      sessionId: z2.string().optional()
    })).mutation(async ({ ctx, input }) => {
      try {
        const imageUrl = await generateImage({
          prompt: input.prompt,
          aspect_ratio: input.aspectRatio
        });
        const userId = ctx.user?.id || "anonymous";
        await createAsset({
          userId,
          sessionId: input.sessionId,
          type: "image",
          prompt: input.prompt,
          url: imageUrl,
          metadata: JSON.stringify({ aspectRatio: input.aspectRatio })
        });
        return { url: imageUrl };
      } catch (error) {
        console.error("Image generation error:", error);
        throw new Error("Failed to generate image. Please try again.");
      }
    }),
    list: publicProcedure.query(async ({ ctx }) => {
      const userId = ctx.user?.id || "anonymous";
      return getUserAssets(userId, "image");
    })
  }),
  // Video Studio - Video Generation - Now public
  video: router({
    generate: publicProcedure.input(z2.object({
      prompt: z2.string(),
      duration: z2.number().optional(),
      aspectRatio: z2.enum(["16:9", "9:16", "1:1"]).optional(),
      sessionId: z2.string().optional()
    })).mutation(async ({ ctx, input }) => {
      try {
        const videoUrl = await generateVideo({
          prompt: input.prompt,
          duration: input.duration,
          aspect_ratio: input.aspectRatio
        });
        const userId = ctx.user?.id || "anonymous";
        await createAsset({
          userId,
          sessionId: input.sessionId,
          type: "video",
          prompt: input.prompt,
          url: videoUrl,
          metadata: JSON.stringify({
            duration: input.duration,
            aspectRatio: input.aspectRatio
          })
        });
        return { url: videoUrl };
      } catch (error) {
        console.error("Video generation error:", error);
        throw new Error("Failed to generate video. Please try again.");
      }
    }),
    list: publicProcedure.query(async ({ ctx }) => {
      const userId = ctx.user?.id || "anonymous";
      return getUserAssets(userId, "video");
    })
  }),
  // Project management - Keep protected for now
  projects: router({
    create: protectedProcedure.input(z2.object({
      name: z2.string(),
      type: z2.string(),
      content: z2.string()
    })).mutation(async ({ ctx, input }) => {
      return createProject({
        userId: ctx.user.id,
        name: input.name,
        type: input.type,
        content: input.content
      });
    }),
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserProjects(ctx.user.id);
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      name: z2.string().optional(),
      content: z2.string().optional(),
      isFavorite: z2.boolean().optional()
    })).mutation(async ({ input }) => {
      await updateProject(input.id, {
        name: input.name,
        content: input.content,
        isFavorite: input.isFavorite
      });
      return { success: true };
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      await deleteProject(input.id);
      return { success: true };
    })
  })
});

// server/_core/context.ts
async function createContext(opts) {
  let user = null;
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }
  return {
    req: opts.req,
    res: opts.res,
    user
  };
}

// server/_core/vite.ts
import express from "express";
import fs from "fs";
import { nanoid } from "nanoid";
import path2 from "path";
import { createServer as createViteServer } from "vite";

// vite.config.ts
import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { defineConfig } from "vite";
import { vitePluginManusRuntime } from "vite-plugin-manus-runtime";
var plugins = [react(), tailwindcss(), jsxLocPlugin(), vitePluginManusRuntime()];
var vite_config_default = defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "client", "public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    host: true,
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1"
    ],
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/_core/vite.ts
async function setupVite(app, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    server: serverOptions,
    appType: "custom"
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app) {
  const distPath = process.env.NODE_ENV === "development" ? path2.resolve(import.meta.dirname, "../..", "dist", "public") : path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app.use(express.static(distPath));
  app.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/_core/index.ts
function isPortAvailable(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}
async function findAvailablePort(startPort = 3e3) {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}
async function startServer() {
  const app = express2();
  const server = createServer(app);
  app.use(express2.json({ limit: "50mb" }));
  app.use(express2.urlencoded({ limit: "50mb", extended: true }));
  registerOAuthRoutes(app);
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext
    })
  );
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
startServer().catch(console.error);
